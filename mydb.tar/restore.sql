--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8
-- Dumped by pg_dump version 14.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "myDb";
--
-- Name: myDb; Type: DATABASE; Schema: -; Owner: myUser
--

CREATE DATABASE "myDb" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE "myDb" OWNER TO "myUser";

\connect "myDb"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: StatusCompany; Type: TYPE; Schema: public; Owner: myUser
--

CREATE TYPE public."StatusCompany" AS ENUM (
    'PENDIENTE',
    'APROBADA',
    'RECHAZADA',
    'RETIRADA',
    'ACTIVO'
);


ALTER TYPE public."StatusCompany" OWNER TO "myUser";

--
-- Name: StatusProject; Type: TYPE; Schema: public; Owner: myUser
--

CREATE TYPE public."StatusProject" AS ENUM (
    'PENDIENTE',
    'ACTIVO',
    'INACTIVO'
);


ALTER TYPE public."StatusProject" OWNER TO "myUser";

--
-- Name: StatusStudent; Type: TYPE; Schema: public; Owner: myUser
--

CREATE TYPE public."StatusStudent" AS ENUM (
    'ASIGNADO',
    'APROBADO',
    'RETIRADO',
    'REPROBADO'
);


ALTER TYPE public."StatusStudent" OWNER TO "myUser";

--
-- Name: TypeDNI; Type: TYPE; Schema: public; Owner: myUser
--

CREATE TYPE public."TypeDNI" AS ENUM (
    'CEDULA',
    'RUC',
    'PASAPORTE'
);


ALTER TYPE public."TypeDNI" OWNER TO "myUser";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Agreement; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."Agreement" (
    id integer NOT NULL,
    code text NOT NULL,
    "dateStart" timestamp(3) without time zone NOT NULL,
    "dateEnd" timestamp(3) without time zone NOT NULL,
    "itvPath" text NOT NULL,
    "agreementPath" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL,
    status public."StatusProject" DEFAULT 'PENDIENTE'::public."StatusProject" NOT NULL,
    "idCompany" integer NOT NULL
);


ALTER TABLE public."Agreement" OWNER TO "myUser";

--
-- Name: Agreement_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."Agreement_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Agreement_id_seq" OWNER TO "myUser";

--
-- Name: Agreement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."Agreement_id_seq" OWNED BY public."Agreement".id;


--
-- Name: Career; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."Career" (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    "dateStart" timestamp(3) without time zone NOT NULL,
    "dateEnd" timestamp(3) without time zone NOT NULL,
    "timeRenovationAgreement" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL,
    "idCoordinator" integer NOT NULL,
    "idViceCoordinator" integer NOT NULL,
    "idRespStepDual" integer NOT NULL
);


ALTER TABLE public."Career" OWNER TO "myUser";

--
-- Name: Career_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."Career_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Career_id_seq" OWNER TO "myUser";

--
-- Name: Career_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."Career_id_seq" OWNED BY public."Career".id;


--
-- Name: Company; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."Company" (
    id integer NOT NULL,
    ruc text NOT NULL,
    name text NOT NULL,
    "dniRepresentLegal" text NOT NULL,
    "nameRepresentLegal" text NOT NULL,
    "lastNameRepresentLegal" text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    address text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL,
    status public."StatusCompany" DEFAULT 'PENDIENTE'::public."StatusCompany" NOT NULL,
    "idCareer" integer NOT NULL,
    "idUser" integer NOT NULL
);


ALTER TABLE public."Company" OWNER TO "myUser";

--
-- Name: Company_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."Company_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Company_id_seq" OWNER TO "myUser";

--
-- Name: Company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."Company_id_seq" OWNED BY public."Company".id;


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."Permission" (
    id integer NOT NULL,
    name text NOT NULL,
    endpoint text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Permission" OWNER TO "myUser";

--
-- Name: Permission_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."Permission_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Permission_id_seq" OWNER TO "myUser";

--
-- Name: Permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."Permission_id_seq" OWNED BY public."Permission".id;


--
-- Name: Project; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."Project" (
    id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL,
    status public."StatusProject" DEFAULT 'PENDIENTE'::public."StatusProject" NOT NULL,
    "idAcademicTutor" integer,
    "idBusinessTutor" integer NOT NULL,
    "idCompany" integer NOT NULL
);


ALTER TABLE public."Project" OWNER TO "myUser";

--
-- Name: Project_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."Project_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Project_id_seq" OWNER TO "myUser";

--
-- Name: Project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."Project_id_seq" OWNED BY public."Project".id;


--
-- Name: Rol; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."Rol" (
    id integer NOT NULL,
    code text,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Rol" OWNER TO "myUser";

--
-- Name: RolHasPermission; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."RolHasPermission" (
    "idRol" integer NOT NULL,
    "idPermission" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL
);


ALTER TABLE public."RolHasPermission" OWNER TO "myUser";

--
-- Name: Rol_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."Rol_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Rol_id_seq" OWNER TO "myUser";

--
-- Name: Rol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."Rol_id_seq" OWNED BY public."Rol".id;


--
-- Name: Student; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."Student" (
    id integer NOT NULL,
    "typeDni" public."TypeDNI" DEFAULT 'CEDULA'::public."TypeDNI" NOT NULL,
    dni text NOT NULL,
    "firstName" text NOT NULL,
    "secondName" text,
    "lastName" text NOT NULL,
    "secondLastName" text,
    email text NOT NULL,
    "idUser" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL,
    status public."StatusStudent" DEFAULT 'APROBADO'::public."StatusStudent" NOT NULL,
    "idCareer" integer NOT NULL
);


ALTER TABLE public."Student" OWNER TO "myUser";

--
-- Name: StudentAssignedToCompany; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."StudentAssignedToCompany" (
    id integer NOT NULL,
    "idStudent" integer NOT NULL,
    "idCompany" integer,
    "idProject" integer,
    "electivePeriod" text NOT NULL,
    "academicPeriod" text NOT NULL,
    parallel text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL
);


ALTER TABLE public."StudentAssignedToCompany" OWNER TO "myUser";

--
-- Name: StudentAssignedToCompany_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."StudentAssignedToCompany_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."StudentAssignedToCompany_id_seq" OWNER TO "myUser";

--
-- Name: StudentAssignedToCompany_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."StudentAssignedToCompany_id_seq" OWNED BY public."StudentAssignedToCompany".id;


--
-- Name: Student_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."Student_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Student_id_seq" OWNER TO "myUser";

--
-- Name: Student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."Student_id_seq" OWNED BY public."Student".id;


--
-- Name: Tutor; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."Tutor" (
    id integer NOT NULL,
    dni text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text NOT NULL,
    "isAcademic" boolean DEFAULT true NOT NULL,
    "idUser" integer NOT NULL,
    "idCareer" integer,
    "idCompany" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Tutor" OWNER TO "myUser";

--
-- Name: Tutor_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."Tutor_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Tutor_id_seq" OWNER TO "myUser";

--
-- Name: Tutor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."Tutor_id_seq" OWNED BY public."Tutor".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: myUser
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    dni text NOT NULL,
    "userName" text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    state boolean DEFAULT true NOT NULL,
    "idRol" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public."User" OWNER TO "myUser";

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: myUser
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."User_id_seq" OWNER TO "myUser";

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: myUser
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: Agreement id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Agreement" ALTER COLUMN id SET DEFAULT nextval('public."Agreement_id_seq"'::regclass);


--
-- Name: Career id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Career" ALTER COLUMN id SET DEFAULT nextval('public."Career_id_seq"'::regclass);


--
-- Name: Company id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Company" ALTER COLUMN id SET DEFAULT nextval('public."Company_id_seq"'::regclass);


--
-- Name: Permission id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Permission" ALTER COLUMN id SET DEFAULT nextval('public."Permission_id_seq"'::regclass);


--
-- Name: Project id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Project" ALTER COLUMN id SET DEFAULT nextval('public."Project_id_seq"'::regclass);


--
-- Name: Rol id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Rol" ALTER COLUMN id SET DEFAULT nextval('public."Rol_id_seq"'::regclass);


--
-- Name: Student id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Student" ALTER COLUMN id SET DEFAULT nextval('public."Student_id_seq"'::regclass);


--
-- Name: StudentAssignedToCompany id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."StudentAssignedToCompany" ALTER COLUMN id SET DEFAULT nextval('public."StudentAssignedToCompany_id_seq"'::regclass);


--
-- Name: Tutor id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Tutor" ALTER COLUMN id SET DEFAULT nextval('public."Tutor_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Agreement; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."Agreement" (id, code, "dateStart", "dateEnd", "itvPath", "agreementPath", "createdAt", "updatedAt", state, status, "idCompany") FROM stdin;
\.
COPY public."Agreement" (id, code, "dateStart", "dateEnd", "itvPath", "agreementPath", "createdAt", "updatedAt", state, status, "idCompany") FROM '$$PATH$$/3510.dat';

--
-- Data for Name: Career; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."Career" (id, code, name, "dateStart", "dateEnd", "timeRenovationAgreement", "createdAt", "updatedAt", state, "idCoordinator", "idViceCoordinator", "idRespStepDual") FROM stdin;
\.
COPY public."Career" (id, code, name, "dateStart", "dateEnd", "timeRenovationAgreement", "createdAt", "updatedAt", state, "idCoordinator", "idViceCoordinator", "idRespStepDual") FROM '$$PATH$$/3502.dat';

--
-- Data for Name: Company; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."Company" (id, ruc, name, "dniRepresentLegal", "nameRepresentLegal", "lastNameRepresentLegal", phone, email, address, "createdAt", "updatedAt", state, status, "idCareer", "idUser") FROM stdin;
\.
COPY public."Company" (id, ruc, name, "dniRepresentLegal", "nameRepresentLegal", "lastNameRepresentLegal", phone, email, address, "createdAt", "updatedAt", state, status, "idCareer", "idUser") FROM '$$PATH$$/3500.dat';

--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."Permission" (id, name, endpoint, "createdAt", "updatedAt", state) FROM stdin;
\.
COPY public."Permission" (id, name, endpoint, "createdAt", "updatedAt", state) FROM '$$PATH$$/3495.dat';

--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."Project" (id, name, description, "createdAt", "updatedAt", state, status, "idAcademicTutor", "idBusinessTutor", "idCompany") FROM stdin;
\.
COPY public."Project" (id, name, description, "createdAt", "updatedAt", state, status, "idAcademicTutor", "idBusinessTutor", "idCompany") FROM '$$PATH$$/3506.dat';

--
-- Data for Name: Rol; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."Rol" (id, code, name, "createdAt", "updatedAt", state) FROM stdin;
\.
COPY public."Rol" (id, code, name, "createdAt", "updatedAt", state) FROM '$$PATH$$/3493.dat';

--
-- Data for Name: RolHasPermission; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."RolHasPermission" ("idRol", "idPermission", "createdAt", "updatedAt", state) FROM stdin;
\.
COPY public."RolHasPermission" ("idRol", "idPermission", "createdAt", "updatedAt", state) FROM '$$PATH$$/3496.dat';

--
-- Data for Name: Student; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."Student" (id, "typeDni", dni, "firstName", "secondName", "lastName", "secondLastName", email, "idUser", "createdAt", "updatedAt", state, status, "idCareer") FROM stdin;
\.
COPY public."Student" (id, "typeDni", dni, "firstName", "secondName", "lastName", "secondLastName", email, "idUser", "createdAt", "updatedAt", state, status, "idCareer") FROM '$$PATH$$/3504.dat';

--
-- Data for Name: StudentAssignedToCompany; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."StudentAssignedToCompany" (id, "idStudent", "idCompany", "idProject", "electivePeriod", "academicPeriod", parallel, "createdAt", "updatedAt", state) FROM stdin;
\.
COPY public."StudentAssignedToCompany" (id, "idStudent", "idCompany", "idProject", "electivePeriod", "academicPeriod", parallel, "createdAt", "updatedAt", state) FROM '$$PATH$$/3508.dat';

--
-- Data for Name: Tutor; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."Tutor" (id, dni, "firstName", "lastName", email, "isAcademic", "idUser", "idCareer", "idCompany", "createdAt", "updatedAt", state) FROM stdin;
\.
COPY public."Tutor" (id, dni, "firstName", "lastName", email, "isAcademic", "idUser", "idCareer", "idCompany", "createdAt", "updatedAt", state) FROM '$$PATH$$/3498.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: myUser
--

COPY public."User" (id, dni, "userName", email, password, "createdAt", "updatedAt", state, "idRol") FROM stdin;
\.
COPY public."User" (id, dni, "userName", email, password, "createdAt", "updatedAt", state, "idRol") FROM '$$PATH$$/3491.dat';

--
-- Name: Agreement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."Agreement_id_seq"', 1, false);


--
-- Name: Career_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."Career_id_seq"', 1, true);


--
-- Name: Company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."Company_id_seq"', 1, false);


--
-- Name: Permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."Permission_id_seq"', 87, true);


--
-- Name: Project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."Project_id_seq"', 1, false);


--
-- Name: Rol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."Rol_id_seq"', 6, true);


--
-- Name: StudentAssignedToCompany_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."StudentAssignedToCompany_id_seq"', 156, true);


--
-- Name: Student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."Student_id_seq"', 156, true);


--
-- Name: Tutor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."Tutor_id_seq"', 3, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: myUser
--

SELECT pg_catalog.setval('public."User_id_seq"', 161, true);


--
-- Name: Agreement Agreement_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Agreement"
    ADD CONSTRAINT "Agreement_pkey" PRIMARY KEY (id);


--
-- Name: Career Career_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Career"
    ADD CONSTRAINT "Career_pkey" PRIMARY KEY (id);


--
-- Name: Company Company_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Company"
    ADD CONSTRAINT "Company_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: RolHasPermission RolHasPermission_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."RolHasPermission"
    ADD CONSTRAINT "RolHasPermission_pkey" PRIMARY KEY ("idRol", "idPermission");


--
-- Name: Rol Rol_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Rol"
    ADD CONSTRAINT "Rol_pkey" PRIMARY KEY (id);


--
-- Name: StudentAssignedToCompany StudentAssignedToCompany_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."StudentAssignedToCompany"
    ADD CONSTRAINT "StudentAssignedToCompany_pkey" PRIMARY KEY (id);


--
-- Name: Student Student_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Student"
    ADD CONSTRAINT "Student_pkey" PRIMARY KEY (id);


--
-- Name: Tutor Tutor_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Tutor"
    ADD CONSTRAINT "Tutor_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Agreement_code_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Agreement_code_key" ON public."Agreement" USING btree (code);


--
-- Name: Career_code_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Career_code_key" ON public."Career" USING btree (code);


--
-- Name: Career_idCoordinator_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Career_idCoordinator_key" ON public."Career" USING btree ("idCoordinator");


--
-- Name: Career_idRespStepDual_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Career_idRespStepDual_key" ON public."Career" USING btree ("idRespStepDual");


--
-- Name: Career_idViceCoordinator_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Career_idViceCoordinator_key" ON public."Career" USING btree ("idViceCoordinator");


--
-- Name: Company_dniRepresentLegal_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Company_dniRepresentLegal_key" ON public."Company" USING btree ("dniRepresentLegal");


--
-- Name: Company_email_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Company_email_key" ON public."Company" USING btree (email);


--
-- Name: Company_idUser_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Company_idUser_key" ON public."Company" USING btree ("idUser");


--
-- Name: Company_name_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Company_name_key" ON public."Company" USING btree (name);


--
-- Name: Company_ruc_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Company_ruc_key" ON public."Company" USING btree (ruc);


--
-- Name: Permission_name_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Permission_name_key" ON public."Permission" USING btree (name);


--
-- Name: Rol_code_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Rol_code_key" ON public."Rol" USING btree (code);


--
-- Name: Rol_name_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Rol_name_key" ON public."Rol" USING btree (name);


--
-- Name: Student_dni_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Student_dni_key" ON public."Student" USING btree (dni);


--
-- Name: Student_email_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Student_email_key" ON public."Student" USING btree (email);


--
-- Name: Student_idUser_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Student_idUser_key" ON public."Student" USING btree ("idUser");


--
-- Name: Tutor_dni_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Tutor_dni_key" ON public."Tutor" USING btree (dni);


--
-- Name: Tutor_email_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Tutor_email_key" ON public."Tutor" USING btree (email);


--
-- Name: Tutor_idUser_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "Tutor_idUser_key" ON public."Tutor" USING btree ("idUser");


--
-- Name: User_dni_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "User_dni_key" ON public."User" USING btree (dni);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_userName_key; Type: INDEX; Schema: public; Owner: myUser
--

CREATE UNIQUE INDEX "User_userName_key" ON public."User" USING btree ("userName");


--
-- Name: Agreement Agreement_idCompany_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Agreement"
    ADD CONSTRAINT "Agreement_idCompany_fkey" FOREIGN KEY ("idCompany") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Career Career_idCoordinator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Career"
    ADD CONSTRAINT "Career_idCoordinator_fkey" FOREIGN KEY ("idCoordinator") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Career Career_idRespStepDual_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Career"
    ADD CONSTRAINT "Career_idRespStepDual_fkey" FOREIGN KEY ("idRespStepDual") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Career Career_idViceCoordinator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Career"
    ADD CONSTRAINT "Career_idViceCoordinator_fkey" FOREIGN KEY ("idViceCoordinator") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Company Company_idCareer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Company"
    ADD CONSTRAINT "Company_idCareer_fkey" FOREIGN KEY ("idCareer") REFERENCES public."Career"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Company Company_idUser_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Company"
    ADD CONSTRAINT "Company_idUser_fkey" FOREIGN KEY ("idUser") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Project Project_idAcademicTutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_idAcademicTutor_fkey" FOREIGN KEY ("idAcademicTutor") REFERENCES public."Tutor"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Project Project_idBusinessTutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_idBusinessTutor_fkey" FOREIGN KEY ("idBusinessTutor") REFERENCES public."Tutor"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Project Project_idCompany_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_idCompany_fkey" FOREIGN KEY ("idCompany") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolHasPermission RolHasPermission_idPermission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."RolHasPermission"
    ADD CONSTRAINT "RolHasPermission_idPermission_fkey" FOREIGN KEY ("idPermission") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolHasPermission RolHasPermission_idRol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."RolHasPermission"
    ADD CONSTRAINT "RolHasPermission_idRol_fkey" FOREIGN KEY ("idRol") REFERENCES public."Rol"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StudentAssignedToCompany StudentAssignedToCompany_idCompany_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."StudentAssignedToCompany"
    ADD CONSTRAINT "StudentAssignedToCompany_idCompany_fkey" FOREIGN KEY ("idCompany") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StudentAssignedToCompany StudentAssignedToCompany_idProject_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."StudentAssignedToCompany"
    ADD CONSTRAINT "StudentAssignedToCompany_idProject_fkey" FOREIGN KEY ("idProject") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StudentAssignedToCompany StudentAssignedToCompany_idStudent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."StudentAssignedToCompany"
    ADD CONSTRAINT "StudentAssignedToCompany_idStudent_fkey" FOREIGN KEY ("idStudent") REFERENCES public."Student"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Student Student_idCareer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Student"
    ADD CONSTRAINT "Student_idCareer_fkey" FOREIGN KEY ("idCareer") REFERENCES public."Career"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Student Student_idUser_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Student"
    ADD CONSTRAINT "Student_idUser_fkey" FOREIGN KEY ("idUser") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Tutor Tutor_idCareer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Tutor"
    ADD CONSTRAINT "Tutor_idCareer_fkey" FOREIGN KEY ("idCareer") REFERENCES public."Career"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tutor Tutor_idCompany_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Tutor"
    ADD CONSTRAINT "Tutor_idCompany_fkey" FOREIGN KEY ("idCompany") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tutor Tutor_idUser_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."Tutor"
    ADD CONSTRAINT "Tutor_idUser_fkey" FOREIGN KEY ("idUser") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_idRol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myUser
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_idRol_fkey" FOREIGN KEY ("idRol") REFERENCES public."Rol"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

